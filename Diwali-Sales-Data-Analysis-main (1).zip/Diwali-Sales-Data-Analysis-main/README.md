# Python_Diwali_Sales_Analysis
Python project - Analyze Diwali sales data among various category like type of item,gender,region,age etc. to improve customer experience and sales


